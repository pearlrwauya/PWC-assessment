from flask import Flask, request, render_template
import requests, json

app = Flask(__name__) #help flask determine root path
app.debug = True      #enable debugging to avoid restarting


def sentimentAnalyis(dmessage):
	subscription_key = "XXXXXXX"
	assert subscription_key

	text_analytics_base_url = "https://eastasia.api.cognitive.microsoft.com/text/analytics/v2.0/"
	sentiment_api_url = text_analytics_base_url + "sentiment"

	documents = {'documents' : [
  	{'id': '1', 'language': 'en', 'text': dmessage}]}

	headers   = {"Ocp-Apim-Subscription-Key": subscription_key}
	response  = requests.post(sentiment_api_url, headers=headers, json=documents)
	sentiments = response.json()
	return sentiments


# routing/mapping - link webpage to
@app.route('/send',methods = ['GET','POST'])      #connect a webpage '/' means root directory
def formSubmission():
	if request.method == 'POST':
		dmessage = request.form['dmessage']
		a = sentimentAnalyis(dmessage)  #returns object with sentiment value
		b = json.dumps(a) 				#converts object to string
		c  = b.split(':')				#splits string into ':' separated parts 
		d = c[2][:-21]					#acquire sentiment value in 2 decimal places 
		sentimentValue = float(d)			#cast string to float

		if sentimentValue<0.5:
			analysis = "Sad"
		elif sentimentValue == 0.5:
			analysis = "Nuetral"
		else:
			analysis = "Happy!"


		return render_template('response.html',analysis = analysis)
	return render_template("index.html")



if __name__ == '__main__': #only run the server only when the file is called directly
	app.run()




