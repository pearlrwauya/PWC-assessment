import re 
import tweepy
import requests 
import json
from tweepy import OAuthHandler 
from textblob import TextBlob 
from flask import Flask, request, render_template

app = Flask(__name__) #help flask determine root path
app.debug = True      #enable debugging to avoid restarting

class TwitterClient(object): 
	''' 
	Generic Twitter Class for sentiment analysis. 
	'''
	def __init__(self): 
		''' 
		Class constructor or initialization method. 
		'''
		# keys and tokens from the Twitter Dev Console 
		consumer_key = 'XXXXX'
		consumer_secret = 'XXXXX'
		access_token = 'XXXXXXX'
		access_token_secret = 'XXXXXXX'
  
		# attempt authentication 
		try: 
			# create OAuthHandler object 
			self.auth = OAuthHandler(consumer_key, consumer_secret) 
			# set access token and secret 
			self.auth.set_access_token(access_token, access_token_secret) 
			# create tweepy API object to fetch tweets 
			self.api = tweepy.API(self.auth) 
		except: 
			print("Error: Authentication Failed") 
  
	def clean_tweet(self, tweet): 
		''' 
		Utility function to clean tweet text by removing links, special characters 
		using simple regex statements. 
		'''
		return ' '.join(re.sub("(@[A-Za-z0-9]+)|([^0-9A-Za-z \t]) |(\w+:\/\/\S+)", " ", tweet).split()) 
  
	def get_tweet_sentiment(self, tweet): 
		''' 
		Utility function to classify sentiment of passed tweet 
		using textblob's sentiment method 
		'''
		# create TextBlob object of passed tweet text 
		analysis = TextBlob(self.clean_tweet(tweet)) 
		# set sentiment 
		if analysis.sentiment.polarity > 0: 
			return 'positive'
		elif analysis.sentiment.polarity == 0: 
			return 'neutral'
		else: 
			return 'negative'
  
	def get_tweets(self, query, count = 10): 
		''' 
		Main function to fetch tweets and parse them. 
		'''
		# empty list to store parsed tweets 
		tweets = [] 
  
		try: 
			# call twitter api to fetch tweets 
			fetched_tweets = self.api.search(q = query, count = count) 
  
			# parsing tweets one by one 
			for tweet in fetched_tweets: 
				# empty dictionary to store required params of a tweet 
				parsed_tweet = {} 
  
				# saving text of tweet 
				parsed_tweet['text'] = tweet.text 
				# saving sentiment of tweet 
				parsed_tweet['sentiment'] = self.get_tweet_sentiment(tweet.text) ###call my own function
  
				# appending parsed tweet to tweets list 
				if tweet.retweet_count > 0: 
					# if tweet has retweets, ensure that it is appended only once 
					if parsed_tweet not in tweets: 
						tweets.append(parsed_tweet) 
				else: 
					tweets.append(parsed_tweet) 
  
			# return parsed tweets 
			return tweets 
  
		except tweepy.TweepError as e: 
			# print error (if any) 
			print("Error : " + str(e)) 





def sentimentAnalyis(dmessage):
	subscription_key = "a1f9e94f2826477a98bfcad34feb3b6e"
	assert subscription_key

	text_analytics_base_url = "https://eastasia.api.cognitive.microsoft.com/text/analytics/v2.0/"
	sentiment_api_url = text_analytics_base_url + "sentiment"

	documents = {'documents' : [
	{'id': '1', 'language': 'en', 'text': dmessage}]}

	headers   = {"Ocp-Apim-Subscription-Key": subscription_key}
	response  = requests.post(sentiment_api_url, headers=headers, json=documents)
	sentiments = response.json()
	return sentiments

@app.route('/home')
def home():
	return render_template("home.html")

# routing/mapping - link webpage to
@app.route('/personal',methods = ['GET','POST'])      #connect a webpage '/' means root directory
def personalSubmission():
	if request.method == 'POST':
		dmessage = request.form['dmessage']
		a = sentimentAnalyis(dmessage)  #returns object with sentiment value
		b = json.dumps(a) 				#converts object to string
		c  = b.split(':')				#splits string into ':' separated parts 
		d = c[2][:-21]					#acquire sentiment value in 2 decimal places 
		sentimentValue = float(d)			#cast string to float

		if sentimentValue<0.5:
			analysis = "Sad"
		elif sentimentValue == 0.5:
			analysis = "Neutral"
		else:
			analysis = "Happy!"


		return render_template('personal_response.html',analysis = analysis)
	return render_template("personal.html")

@app.route('/twitter',methods = ['GET','POST'])      #connect a webpage '/' means root directory
def twitterSubmission():
	if request.method == 'POST':
		dmessage = request.form['dmessage']
		# creating object of TwitterClient Class 
		api = TwitterClient() 
		# calling function to get tweets 
		tweets = api.get_tweets(query = dmessage, count = 200) 
		# picking positive tweets from tweets 
		ptweets = [tweet for tweet in tweets if tweet['sentiment'] == 'positive'] 
		# picking negative tweets from tweets 
		ntweets = [tweet for tweet in tweets if tweet['sentiment'] == 'negative'] 
		#picking neutral tweets from tweets 
		neutweets = [tweet for tweet in tweets if tweet['sentiment'] == 'neutral'] 
		# percentage of neutral tweets 
		neutral = 100*len(neutweets)/len(tweets)
		negative = 100*len(ntweets)/len(tweets)
		positive = 100*len(ptweets)/len(tweets)

		analysis = "Positive: "+str(positive)+"% Negative: "+str(negative)+"% Neutral: "+str(neutral)+"%"


		return render_template('twitter_response.html',analysis = analysis)
	return render_template("twitter.html")












if __name__ == '__main__': #only run the server only when the file is called directly
	app.run()




